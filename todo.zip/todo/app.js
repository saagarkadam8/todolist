'use strict';
var express = require('express');
var app = express();

var mongoose = require('mongoose');
var Product = require('./restapi/models/todoModel');
var bodyParser = require('body-parser');
mongoose.connect('mongodb://localhost/todo_db', { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true, keepAlive: true, autoReconnect: true });
mongoose.Promise = global.Promise;
module.exports = mongoose;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false })); // This code use for send data by form post method to route 
 

 app.use(express.static(__dirname + '/', {
    maxAge: 86400000,
    setHeaders: function(res, path) {
        res.setHeader("Expires", new Date(Date.now() + 2592000000 * 30).toUTCString());
    }
}))


const path = require('path');
var http = require('http');
var url = require('url');

// Start Template code here...
app.set('views', __dirname);
app.engine('html', require('ejs').renderFile);
app.use(express.static(path.join(__dirname, '')));
// End Template code here..

//takes us to the root(/) URL
app.get('/', function (req, res) {
 res.sendfile('todo.html');
//res.send('Welcome todo app!');
});
 
var routes = require('./restapi/routes/commonRoutes');
routes(app);
 
//the server is listening on port 3000 for connections
app.listen(3000, function () {
console.log('Todo App listening on port 3000!')
});