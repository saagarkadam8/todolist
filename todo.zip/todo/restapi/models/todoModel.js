'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var DateNow = function() {
    var date = new Date();
    var today = date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear();
    return today;
};

var Schema = new Schema({

    todo: { type: String, required: [true, 'todo name cannot be left blank.'] },

    desc: { type: String },

    date: { type: String, default: DateNow },

    status: { type: String, default: '1' },

});

module.exports = mongoose.model('Todos', Schema);



























function encrypt(text) {
    var cipher = crypto.createCipher('aes-256-cbc', 'd6F3Efeq')
    var crypted = cipher.update(text, 'utf8', 'hex')
    crypted += cipher.final('hex');
    return crypted;
}

function decrypt(text) {
    var decipher = crypto.createDecipher('aes-256-cbc', 'd6F3Efeq')
    var dec = decipher.update(text, 'hex', 'utf8')
    dec += decipher.final('utf8');
    return dec;
}