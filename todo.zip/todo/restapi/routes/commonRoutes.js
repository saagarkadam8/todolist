'use strict';
module.exports = function(app) {

    var todo = require('../controllers/todoController');

    app.route('/todo/create')
        .post(todo.create_todo);

    app.route('/todo/todo_show')
        .post(todo.todo_show);

    app.route('/todo/delete')
        .post(todo.todo_delete);


};