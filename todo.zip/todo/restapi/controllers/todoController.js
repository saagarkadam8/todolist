'use strict';

var express = require('express');
var app = express();
var mongoose = require('mongoose');
var url = "mongodb://localhost:27017/";
var MongoClient = require("mongodb").MongoClient;
mongoose.Promise = global.Promise;
var assert = require('assert');

const path = require('path');

exports.create_todo = function(req, res) {

    var Product = mongoose.model('Todos');
    var new_product = new Product(req.body);
    //console.log(new_product);
    new_product.save(function(err, user) {
        if (err) {
            console.log('err.name= ' + err.name);
            console.log('err.message= ' + err.message);
        } else {
              res.send('OK');
        }
    });
}


var arr = [];
exports.todo_show = function(req, res) {

    var Product = mongoose.model('Todos');
    Product.find({ "status": '1' }, function(err, user) {
        if (err) {
            return res.status(200).json({ "status": 0, "message": 'No Update Available.', "record_status": 0 });
            res.send(err);
        } else if (typeof user[0] !== 'undefined' && typeof user[0]._id !== 'undefined') {
            user.forEach(function(entry) {

                var arr_object = {
                    "_id": entry._id,
                    "todo": entry.todo,
                    "desc": entry.desc,
                    "date": entry.date,
                    "status": entry.status,
                }

                arr.push(arr_object);
                //console.log('arr_object='+arr_object);
            });
        }

        if (arr.length >= 1) {
            var new_array = [];
            new_array = arr;
            arr = [];

            return res.status(200).json({ "data": new_array, "record_status": 1 });

        } else {
            return res.status(200).json({ "status": 0, "message": 'No Update Available.', "record_status": 0 });
        }
    });
};


var arr = [];
exports.todo_delete = function(req, res) {

    var Product = mongoose.model('Todos');
    var id = mongoose.Types.ObjectId(req.body.ids);

    MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, client) {
        if (err) throw err;
        assert.equal(null, err);
        var db = client.db('todo_db');

        db.collection("todos").updateMany({ _id: id }, { $set: { status: 0 } }, { new: true }, function(err, user1) {
            if (err) {
                res.send(err);
            } else {
                res.send('OK');
            }
        });

    });
};



